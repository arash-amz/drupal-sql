<?php
$connectionInfo = array(
    "Database" => "irancard_MSCRM",
    "UID" => "test",
    "PWD" => "123456",
    "CharacterSet" => 'UTF-8');
$conn = sqlsrv_connect("192.168.0.33", $connectionInfo);


$sql = "Yara_SP_Portal_Get_Shahr";
$stmt = sqlsrv_query($conn,$sql);
if($stmt === false) {
    die( print_r( sqlsrv_errors(), true) );
}

while ($row = sqlsrv_fetch_array($stmt,SQLSRV_FETCH_ASSOC)){
	// if ($outp != "") {$outp .= ",";}
    //$outp .= '{"name":"'  . $rs["new_name"] . '",';
	//$rows[] = $row;
	$id = $row['new_shahrid'];
	$name = $row['new_name'];
    $parent_id = $row['new_ostan'];
   // $site = $row['new_site'];
  //  $specialservice = $row['new_specialservice'];
  //  $keyword = $row['new_keyword'];
  //  $blue = $row['new_blue'];
  //  $silver = $row['new_silver'];
  //  $gold = $row['new_gold'];
  //  $platinium = $row['new_platinium'];
    $rows[] = array(
		'id' => $id,
       'name' => $name,
       'parent_id' => $parent_id ,
	   
      // 'specialservice' => $specialservice,
       //'keyword' => $keyword,
      // 'blue' => $blue,
      // 'silver' => $silver,
      // 'gold' => $gold,
      // 'platinium' => $platinium,
    );
}
//print_r (json_encode($rows,JSON_UNESCAPED_UNICODE));
//$outp ='{"records":['.$name.']}';

 $output = json_encode(array('cities' => $rows));
echo  ($output);
//echo json_encode($rows);
//var_dump(json_encode($rows));

//sqlsrv_free_stmt($stmt);
?>